import re
import math

# Common passwords list for uniqueness check
COMMON_PASSWORDS = [
    '123456', 'password', '123456789', '12345678', '12345', '1234567', '1234567890', 'qwerty'
    # Add more common passwords here or load from a file
]

def check_password_length(password):
    return len(password) >= 12

def check_character_types(password):
    patterns = {
        'uppercase': r'[A-Z]',
        'lowercase': r'[a-z]',
        'numeric': r'[0-9]',
        'special': r'[!@#$%^&*(),.?":{}|<>]'
    }
    results = {key: re.search(pattern, password) is not None for key, pattern in patterns.items()}
    return results

def check_uniqueness(password):
    return password not in COMMON_PASSWORDS

def calculate_entropy(password):
    charset_size = 0
    if re.search(r'[A-Z]', password):
        charset_size += 26
    if re.search(r'[a-z]', password):
        charset_size += 26
    if re.search(r'[0-9]', password):
        charset_size += 10
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        charset_size += 32
    return len(password) * math.log2(charset_size)

def provide_feedback(password):
    length_ok = check_password_length(password)
    char_types_ok = check_character_types(password)
    uniqueness_ok = check_uniqueness(password)
    entropy = calculate_entropy(password)

    feedback = []
    if not length_ok:
        feedback.append("Password should be at least 12 characters long.")
    if not char_types_ok['uppercase']:
        feedback.append("Add uppercase letters.")
    if not char_types_ok['lowercase']:
        feedback.append("Add lowercase letters.")
    if not char_types_ok['numeric']:
        feedback.append("Add numbers.")
    if not char_types_ok['special']:
        feedback.append("Add special characters.")
    if not uniqueness_ok:
        feedback.append("Avoid common passwords.")
    if entropy < 50:
        feedback.append("Increase password complexity for higher entropy.")

    return feedback

def check_password_strength(password):
    feedback = provide_feedback(password)
    if not feedback:
        return "Strong", []
    return "Weak", feedback

# Command-line interface for the tool
def main():
    password = input("Enter a password to check its strength: ")
    strength, feedback = check_password_strength(password)
    print(f"Password strength: {strength}")
    if feedback:
        print("Suggestions to improve your password:")
        for suggestion in feedback:
            print(f" - {suggestion}")

if __name__ == "__main__":
    main()

